﻿using System;

namespace zad1
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
