﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad2
{
    class Program
    {
        //да се напише програма която прочита от конзолата два списака от номера на ученици
        //първи на присъстващите на обучение по математика
        //втория на присъстващите на обучеие по физика
        //да се изведе списък на номерата на учениците присъствали на поне едно обучение
        public static List<int> Union(List<int> fList, List<int> sList)
        {
            List<int> unionList = new List<int>();
            unionList.AddRange(fList);
            foreach (var item in sList)
            {
                if (!unionList.Contains(item))
                {
                    unionList.Add(item);
                }
            }
            return unionList;
        }
        static void Main(string[] args)
        {
            List<int> math = Console.ReadLine().Split(' ').Select(int.Parse).ToList();
            List<int> physics = Console.ReadLine().Split(' ').Select(int.Parse).ToList();
            List<int> unionList = Union(math, physics);
            Console.WriteLine(string.Join(" ", unionList));
        }
    }
}
