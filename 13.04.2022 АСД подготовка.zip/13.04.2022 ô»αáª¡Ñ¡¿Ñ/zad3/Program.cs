﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad3
{
    class Program
    {
        //дадена е последователност от цели числа
        //върнете като резултат числото, което се повтаря последователно най-много пъти
        static void Main(string[] args)
        {
            List<int> list = Console.ReadLine().Split(' ').Select(int.Parse).ToList();
            int currVallue = list[0];
            int currCount = 1;
            int maxVallue = currVallue;
            int maxCount = 1;
            for (int i = 1; i < list.Count; i++)
            {
                if (list[i] == currVallue)
                {
                    currCount++;
                    if (currCount > maxCount)
                    {
                        maxCount = currCount;
                        maxVallue = currVallue;
                    }
                }
                else
                {
                    if (currCount > maxCount)
                    {
                        maxCount = currCount;
                        maxVallue = currVallue;
                    }
                    currCount = 1;
                    currVallue = list[i];
                }
            }
            Console.WriteLine("Най-много се повтаря {0}", maxVallue);
        }
    }
}
