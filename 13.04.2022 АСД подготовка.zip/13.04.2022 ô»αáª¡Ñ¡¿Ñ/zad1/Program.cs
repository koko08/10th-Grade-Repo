﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad1
{
    class Program
    {
        public static List<string> Intersect(List<string> fStudents, List<string> sStudents)
        {
            List<string> iList = new List<string>();
            foreach (var item in fStudents)
            {
                if (sStudents.Contains(item) == true)
                {
                    iList.Add(item);
                }
            }
            return iList;
        }
        static void Main(string[] args)
        {
            List<string> fStudents = Console.ReadLine().Split(' ').ToList();
            List<string> sStudents = Console.ReadLine().Split(' ').ToList();
            List<string> iList = Intersect(fStudents, sStudents);
            Console.WriteLine(string.Join(" ", iList));
        }
    }
}