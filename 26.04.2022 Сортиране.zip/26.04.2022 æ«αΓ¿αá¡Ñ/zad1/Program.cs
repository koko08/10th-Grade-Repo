﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace zad1
{
    class Program
    {
        private static void Swap(List<int> list, int index, int max)
        {
            int temp = list[index];
            list[index] = list[max];
            list[max] = temp;

        }
        static void Main(string[] args)
        {
            List<int> list = Console.ReadLine().Split(' ').Select(int.Parse).ToList();
            for (int index = 0; index < list.Count; index++)
            {
                int max = index;
                for (int current = index + 1; current < list.Count; current++)
                {
                    if (list[current] > list[max]) //промени > за да сменяш между възходящо и низходящо подреждане
                    {
                        max = current;
                    }
                }
                Swap(list, index, max);
                Console.WriteLine(string.Join(" ", list));
            }
        }
    }
}
