﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad1
{
    class Program
    {
        static void Swap(List<int> list, int index, int max)
        {
            int temp = list[index];
            list[index] = list[max];
            list[max] = temp;
        }
        static void Main(string[] args)
        {
            List<int> points = Console.ReadLine().Split(' ').Select(int.Parse).ToList();
            for (int index = 0; index < points.Count; index++)
            {
                int max = index;
                for (int current = index + 1; current < points.Count; current++)
                {
                    if (points[current] > points[max])
                    {
                        max = current;
                    }
                }
                Swap(points, index, max);
            }
            Console.WriteLine("Spisak s klasirani: ");
            for (int i = 0; i <= 9; i++)
            {
                Console.WriteLine(points[i]);
            }
            Console.WriteLine("Spisak s reservi: ");
            for (int i = 10; i <= points.Count; i++)
            {
                Console.WriteLine(points[i]);
            }
        }
    }
}
