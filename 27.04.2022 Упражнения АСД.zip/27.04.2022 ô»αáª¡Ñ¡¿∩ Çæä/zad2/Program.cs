﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad2
{
    class Program
    {
        static void Swap(List<double> list, int index, int max)
        {
            double temp = list[index];
            list[index] = list[max];
            list[max] = temp;
        }
        static void Main(string[] args)
        {
            List<double> heigh = Console.ReadLine().Split(' ').Select(double.Parse).ToList();
            for (int index = 0; index < heigh.Count; index++)
            {
                int max = index;
                for (int current = index + 1; current < heigh.Count; current++)
                {
                    if (heigh[current] > heigh[max])
                    {
                        max = current;
                    }
                }
                Swap(heigh, index, max);
            }
            int num1 = int.Parse(Console.ReadLine());
            int num2 = int.Parse(Console.ReadLine());
            Console.WriteLine(heigh[num1 - 1]);
            Console.WriteLine(heigh[num2 - 1]);
        }
    }
}
