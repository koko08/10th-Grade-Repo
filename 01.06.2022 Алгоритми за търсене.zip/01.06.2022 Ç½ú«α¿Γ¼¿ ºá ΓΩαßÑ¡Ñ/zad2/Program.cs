﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad2
{
    class Program
    {

        public static int Linear<T>(T[] elements, T key) where T : IComparable
        {
            for (int index = 0; index < elements.Length; index++)
            {
                if (elements[index].CompareTo(key) == 0)
                {
                    return index;
                }
            }
            return -1;
        }
        static void Main(string[] args)
        {
            char[] characters = new char[] {'-', '*', '#', '^' };
            Console.WriteLine("Character: ");
            char n = char.Parse(Console.ReadLine());
            if (Linear(characters, n) >= 0)
            {
                Console.WriteLine("Character {0} is in possition {1}", n, Linear(characters, n) + 1);
            }
            else 
            {
                Console.WriteLine("Character {0} is not in the array", n);
            }
        }
    }
}
