﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad1
{
    class Program
    {
        public static int Linear<T>(T[] elements, T key) where T : IComparable
        {
            for (int i = 0; i < elements.Length; i++)
            {
                if (elements[i].CompareTo(key) == 0)
                {
                    return i;
                }
            }
            return -1;
        }
        static void Main(string[] args)
        {
            int[] collection = new int[] { 3, 8, 9, 10, 17, 29 };
            Console.Write("Number: ");
            int n = int.Parse(Console.ReadLine());
            if (Linear(collection, n) >= 0)
            {
                Console.WriteLine("Number {0} is in possition {1}", n,  Linear(collection, n) + 1);
            }
            else
            {
                Console.WriteLine("There is no {0}", n);
            }
        }
    }
}
