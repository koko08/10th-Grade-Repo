﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad3
{
    class Program
    {
        public static int Binary<T>(T[] elements, T key) where T : IComparable
        {
            int start = 0, end = elements.Length - 1;
            while (end >= start)
            {
                int mid = (start + end) / 2;
                if (elements[mid].CompareTo(key) > 0)
                {
                    end = mid - 1;
                }
                else if (elements[mid].CompareTo(key) < 0)
                {
                    start = mid + 1;
                }
                else 
                {
                    return mid;
                }
            }
            return -1;
        }
        static void Main(string[] args)
        {
            int[] collection = new int[] { 12, 8, 9, 19, 17, 29, 4};
            collection = collection.OrderBy(item => item).ToArray();
            Console.Write("Number: ");
            int n = int.Parse(Console.ReadLine());
            if (Binary(collection, n) >= 0)
            {
                Console.WriteLine("Number {0} is in possition {1}", n, Binary(collection, n) + 1);
            }
            else
            {
                Console.WriteLine("There is no {0}", n);
            }
        }
    }
}
